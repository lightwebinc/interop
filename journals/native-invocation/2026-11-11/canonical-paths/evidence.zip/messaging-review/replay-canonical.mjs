import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { prepareFrozenComponentReplay } from '../../scripts/frozen-component-replay.mjs';
const root=process.cwd(),out=path.join(root,'out/preparation-review-20261111'),sha=b=>createHash('sha256').update(b).digest('hex');
const cache=path.join(root,'out/messaging-native-verifier'),receipt=JSON.parse(fs.readFileSync(path.join(cache,'verifier-preparation.json')));
assert.equal(receipt.schema,'tpnil-native-messaging-verifier-preparation@1');assert.equal(receipt.serviceRuntimePrepared,false);
for(const [name,digest] of Object.entries(receipt.source.files))assert.equal(sha(fs.readFileSync(path.join(root,name))),digest);
assert.equal(sha(fs.readFileSync(receipt.archive.path)),receipt.archive.sha256);
assert.equal(sha(fs.readFileSync(path.join(receipt.package.path,'package.json'))),receipt.package.jsonSha256);
assert.equal(sha(fs.readFileSync(path.join(receipt.package.path,'package-lock.json'))),receipt.package.lockSha256);
assert.equal(sha(fs.readFileSync(path.join(receipt.package.path,'node_modules/@bsv/sdk/package.json'))),receipt.sdk.packageSha256);
assert.equal(sha(fs.readFileSync(path.join(receipt.package.path,receipt.sdk.entry))),receipt.sdk.entrySha256);
const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'tpnil-prep-review-')),frozen=path.join(fs.realpathSync(temporary),'source'),source='c338a93c97ffebeeef318e679ff82b7dbf309dd5';
const rows=[];
try {
 const extraction=prepareFrozenComponentReplay(root,source,frozen);
 for(const index of [1,2]){
  const directory=path.join(root,`out/native-ci-42711700295/repetition-${index}/evidence/integrated`);
  const result=spawnSync(process.execPath,[path.join(frozen,'scripts/verify-native-messaging.mjs'),directory],{cwd:frozen,env:{...process.env,TPNIL_MESSAGING_PATHS:path.join(cache,'paths.json')},encoding:'utf8',timeout:60000});
  fs.writeFileSync(path.join(out,`repetition-${index}-canonical.log`),result.stdout+'\n'+result.stderr);
  assert.equal(result.status,0,result.stderr);const report=JSON.parse(result.stdout);assert.equal(report.verified,true);assert.equal(report.assertions,6);
  rows.push({index,exitCode:result.status,assertions:report.assertions,report});
 }
 fs.writeFileSync(path.join(out,'replay-review-canonical.json'),JSON.stringify({claim:'INDEPENDENT_REVIEW_OF_RETAINED_ENGINEERING_EVIDENCE',source,extraction,preparedSource:receipt.source,preparationReceiptSha256:sha(fs.readFileSync(path.join(cache,'verifier-preparation.json'))),newNativeSessions:0,repetitions:rows},null,2)+'\n');
 console.log(JSON.stringify({verified:true,source,repetitions:rows.map(({index,assertions,exitCode})=>({index,assertions,exitCode})),newNativeSessions:0}));
} finally { fs.rmSync(temporary,{recursive:true,force:true}); }
