import json,pathlib,tempfile,shutil,subprocess,hashlib,os
root=pathlib.Path.cwd(); original=root/'out/descendant-storage-matrix-20261109-4';results=[]
def altered_report(p,m,fn):
 row=m['runs'][0]; f=p/row['report']['file']; r=json.loads(f.read_text());fn(r); f.write_text(json.dumps(r));b=f.read_bytes();row['report']['sha256']=hashlib.sha256(b).hexdigest();row['report']['bytes']=len(b)
mutations=[('omitted-critical-source',lambda p,m:m['inputs'].pop('synthesis/src/storage-sync/verify-descendant.ts')),('missing-repetition',lambda p,m:m['runs'].pop()),('fixture-identity-substitution',lambda p,m:m['runs'][0].update(fixtureOwnerKey='91'*32)),('adapter-source-substitution',lambda p,m:altered_report(p,m,lambda r:r['components']['source']['typescriptStorageAdapter']['adapter'].update(sha256='00'*32))),('cleanup-overclaim',lambda p,m:altered_report(p,m,lambda r:r['cleanup']['errors'].append('service still running'))),('source-reachability-overclaim',lambda p,m:altered_report(p,m,lambda r:r.update(sourceReachable=True)))]
for name,mutate in mutations:
 with tempfile.TemporaryDirectory(prefix='tpnil-descendant-tamper-') as temporary:
  p=pathlib.Path(temporary)/'pack';shutil.copytree(original,p);m=json.loads((p/'matrix.json').read_text());mutate(p,m);(p/'matrix.json').write_text(json.dumps(m))
  result=subprocess.run(['/Users/tyeverett/.nvm/versions/node/v24.22.1/bin/node','scripts/verify-descendant-storage-matrix.mjs',str(p)],cwd=root,capture_output=True,text=True)
  results.append({'mutation':name,'exitCode':result.returncode,'rejected':result.returncode!=0,'output':(result.stdout+result.stderr)[-1800:]})
assert all(r['rejected'] for r in results)
(root/'out/descendant-storage-matrix-20261109-4-tampering.json').write_text(json.dumps({'schema':'tpnil-descendant-matrix-tampering@1','result':'PASS','mutations':results},indent=2)+'\n')
print(json.dumps({'result':'PASS','rejectedMutations':len(results)}))
